﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Linq;

namespace JsonRead
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = Path.Combine(Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName, "orgs.json");
            StreamReader SR = new StreamReader(filePath);
            string jsondata = SR.ReadToEnd();

            List<Logindata> logindata = JsonConvert.DeserializeObject<List<Logindata>>(jsondata);
            MaxId(logindata);
            MinId(logindata);
        }


        public static void MaxId(List<Logindata> logindata)
        {
            var Q1 = (from maxid in logindata
                      select maxid).Max(x => x.id);
            var Q2 = (from p in logindata
                      where p.id == Q1
                      select p).ToList();
            var Maxdata = JsonConvert.SerializeObject(Q2);
            Console.WriteLine("MaxId records: \n"+Maxdata);
        }


        public static void MinId(List<Logindata> logindata)
        {
            var Q1 = (from maxid in logindata
                      select maxid).Min(x => x.id);
            var Q2 = (from p in logindata
                      where p.id == Q1
                      select p).ToList();
            var Mindata = JsonConvert.SerializeObject(Q2);
            Console.WriteLine("MinId Records \n"+Mindata);
        }
    }
    public class Logindata
    {
        public string login { get; set; }
        public int id { get; set; }
        public string node_id { get; set; }
        public string url { get; set; }
        public string repos_url { get; set; }
        public string events_url { get; set; }
        public string hooks_url { get; set; }
        public string issues_url { get; set; }
        public string members_url { get; set; }
        public string public_members_url { get; set; }
        public string avatar_url { get; set; }
        public string description { get; set; }
    }
}
