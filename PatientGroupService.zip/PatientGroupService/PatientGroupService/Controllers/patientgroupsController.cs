﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace PatientGroupService.Controllers
{
    //  using System.Web.Http;

    [Route("api/[controller]")]
    [ApiController]
    public class patientgroupsController : ControllerBase
    {

        [Route("Calculate")]
        [HttpPost]
        public ActionResult Calculator([FromBody] IEnumerable<IEnumerable<int>> matrix)
        {

            
            int[,] array = new int[matrix.Count(), matrix.ToArray().ToArray().Count()];

            for(int lineCounter = 0;lineCounter<matrix.Count();lineCounter++)
            {
                for (var i = 0; i < matrix.ToArray()[lineCounter].Count(); i++)
                {
                    array[lineCounter, i] =(matrix.ToArray()[lineCounter]).ToArray()[i];
                }

            }
           
            // check 1's in set of Directions and resturn Result
            int result = CountPoints(array, matrix.Count(), matrix.ToArray().ToArray().Count());
            return Ok(new
            {
                numberofGroups = result

            }) ;
        }


        [NonAction]
        public  void CheckVHO(int[,] M, int i, int j, int ROW, int COL)
        {

            // Base condition
            // if i less than 0 or j less than 0 or i greater than ROW-1 or j greater than COL-  or if M[i][j] != 1 then we will simply return
            if (i < 0 || j < 0 || i > (ROW - 1) || j > (COL - 1) || M[i, j] != 1)
            {
                return;
            }
            //checking with condition =1
            if (M[i, j] == 1)
            {
                M[i, j] = 0;
                CheckVHO(M, i + 1, j, ROW, COL);     //right side traversal
                CheckVHO(M, i - 1, j, ROW, COL);     //left side traversal
                CheckVHO(M, i, j + 1, ROW, COL);     //upward side traversal
                CheckVHO(M, i, j - 1, ROW, COL);     //downward side traversal
                CheckVHO(M, i + 1, j + 1, ROW, COL); //upward-right side traversal
                CheckVHO(M, i - 1, j - 1, ROW, COL); //downward-left side traversal
                CheckVHO(M, i + 1, j - 1, ROW, COL); //downward-right side traversal
                CheckVHO(M, i - 1, j + 1, ROW, COL); //upward-left side traversal
            }
        }
         
        [NonAction]
        public  int CountPoints(int[,] M,int ROW,int COL)
        {
            
            int count = 0;
            for (int i = 0; i < ROW; i++)
            {
                for (int j = 0; j < COL; j++)
                {
                    if (M[i, j] == 1)
                    {
                        M[i, j] = 0;
                        count++;
                        CheckVHO(M, i + 1, j, ROW, COL);     //right side traversal
                        CheckVHO(M, i - 1, j, ROW, COL);     //left side traversal
                        CheckVHO(M, i, j + 1, ROW, COL);     //upward side traversal
                        CheckVHO(M, i, j - 1, ROW, COL);     //downward side traversal
                        CheckVHO(M, i + 1, j + 1, ROW, COL); //upward-right side traversal
                        CheckVHO(M, i - 1, j - 1, ROW, COL); //downward-left side traversal
                        CheckVHO(M, i + 1, j - 1, ROW, COL); //downward-right side traversal
                        CheckVHO(M, i - 1, j + 1, ROW, COL); //upward-left side traversal
                    }
                }
            }
            return count;
        }
    }
}